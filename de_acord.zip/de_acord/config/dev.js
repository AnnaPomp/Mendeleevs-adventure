module.exports={
    port:13756,
    mongoURI:'mongodb+srv://annapomparau:7ZJwhWoTNoeDt29K@cluster0.bwn0czw.mongodb.net/',
};
