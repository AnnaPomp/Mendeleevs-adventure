using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class profsauelev : MonoBehaviour
{
     public void prof()
{
SceneManager.LoadScene("Createprof");
}
  public void elev()
{
SceneManager.LoadScene("Create");
}
  public void amdeja()
{
SceneManager.LoadScene("Login");
}
  public void cacat()
{
SceneManager.LoadScene("Tutorial");
}
}
