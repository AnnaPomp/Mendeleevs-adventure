using UnityEngine;
using System;
using System.Collections;
public class CharacterSpawner : MonoBehaviour
{
    public GameObject characterPrefab; // Assign your character prefab in the Unity Editor
    public float spawnDelay = 3f; // Set the delay time in seconds

    private void Start()
    {
        StartCoroutine(SpawnCharacterWithDelay());
    }

    private IEnumerator SpawnCharacterWithDelay()
    {
        yield return new WaitForSeconds(spawnDelay);
        Instantiate(characterPrefab, transform.position, Quaternion.identity);
    }
}
