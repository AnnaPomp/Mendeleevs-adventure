using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class meniuprof : MonoBehaviour
{
       public void TestAlchene()
{
SceneManager.LoadScene("TestAlchene1");
}
  public void TestAlcani()
{
SceneManager.LoadScene("TestAlcani1");
}
  public void TestAlcadiene()
{
SceneManager.LoadScene("TestAlcadiene1");
}
  public void CCClorurare()
{
SceneManager.LoadScene("CCClorurare");
}
  public void CCAlchene()
{
SceneManager.LoadScene("CCAlchene");
}
  public void CCAlcani()
{
SceneManager.LoadScene("CCAlcani");
}
  public void Flashcards()
{
SceneManager.LoadScene("flesh");
}
 public void flashcardalcani()
{
SceneManager.LoadScene("flashcardalcani");
}
 public void flashcardalcadiene()
{
SceneManager.LoadScene("flashcardalcadiene");
}
 public void flashcardalchine()
{
SceneManager.LoadScene("flashcardalchine");
}
 public void nivurm4()
{
SceneManager.LoadScene("Level4");
}

}
