using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class levell : MonoBehaviour
{
     public void amdeja1()
{
SceneManager.LoadScene("Loginprof");
}
    public void crieiti()
{
SceneManager.LoadScene("Loginprof");
}
 public void profse()
{
SceneManager.LoadScene("profsauelev");
}
 public void level2()
{
SceneManager.LoadScene("Level 2");
}
}
