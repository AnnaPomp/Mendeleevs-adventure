
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class answerscript : MonoBehaviour
{
    // Culoarea de start a imaginii
    public Color startColor;

    // Indică dacă răspunsul este corect
    public bool isCorrect = false;

    // Referință către managerul de quiz
    public quizmanager quizManager;

    private void Start()
    {
        // Salvează culoarea inițială a imaginii
        startColor = GetComponent<Image>().color;
    }

    public void Answers()
    {
        if (isCorrect)
        {
            Debug.Log("Correct");
            quizManager.correct();
        }
        else
        {
            Debug.Log("Gresit");
            quizManager.wrong();
        }
    }
}
```

Acum comentariile sunt mai concise și acoperă doar aspectele principale ale codului.