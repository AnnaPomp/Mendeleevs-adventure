using UnityEngine;

public class GroundShaker : MonoBehaviour
{
    public float shakeIntensity = 0.1f; // Intensitatea tremurului
    public float shakeDuration = 1.0f;  // Durata tremurului

    private float shakeTimer = 0.0f;    // Timer pentru durata tremurului
    private Vector3 originalPosition;   // Poziția originală a terenului
    private bool isShaking = false;     // Indicator pentru tremur

    void Start()
    {
        originalPosition = transform.position; // Salvează poziția inițială
    }

    void Update()
    {
        if (isShaking)
        {
            if (shakeTimer > 0)
            {
                shakeTimer -= Time.deltaTime;
                transform.position = originalPosition + Random.insideUnitSphere * shakeIntensity;
            }
            else
            {
                transform.position = originalPosition;
                isShaking = false;
            }
        }
    }

    public void StartShake()
    {
        if (!isShaking)
        {
            shakeTimer = shakeDuration;
            isShaking = true;
        }
    }
}
