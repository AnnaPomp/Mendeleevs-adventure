using UnityEngine;

public class hyperlink : MonoBehaviour
{
    // URL to open
    [SerializeField]private string url = "https://www.example.com";

    // Method to be called on button click
    public void OpenURL()
    {
        Application.OpenURL(url);
    }
}
