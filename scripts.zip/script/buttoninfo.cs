using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class buttoninfo : MonoBehaviour
{
    // ID-ul articolului din magazin
    public int ItemID; 

    // Textul care afișează prețul
    public Text PriceTxt;

    // Textul care afișează cantitatea
    public Text QuantityTxt;

    // Referință către managerul magazinului
    public GameObject ShopManager;
       
    void Update()
    {
        // Actualizează textul prețului pe baza informațiilor din managerul magazinului
        PriceTxt.text = "Preț: $" + ShopManager.GetComponent<ShopManagerScript>().shopItems[2, ItemID].ToString();

        // Actualizează textul cantității pe baza informațiilor din managerul magazinului
        QuantityTxt.text = ShopManager.GetComponent<ShopManagerScript>().shopItems[3, ItemID].ToString();
    }
}
