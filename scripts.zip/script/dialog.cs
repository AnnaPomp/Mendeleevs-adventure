using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Dialogue : MonoBehaviour
{
    // Referință către componenta TextMeshPro pentru a afișa textul dialogului
    public TextMeshProUGUI textComponent;

    // Array de string-uri care conțin liniile dialogului
    public string[] lines;

    // Viteza de afișare a textului
    public float textSpeed;

    // Indexul curent al liniei de dialog
    private int index;

    // Start este apelat înainte de primul frame update
    void Start()
    {
        textComponent.text = string.Empty;
        StartDialogue();
    }

    // Update este apelat o dată pe frame
    void Update()
    {
        // Verifică dacă s-a apăsat butonul stâng al mouse-ului
        if (Input.GetMouseButtonDown(0))
        {
            // Dacă textul curent este complet afișat, trece la următoarea linie
            if (textComponent.text == lines[index])
            {
                NextLine();
            }
            else
            {
                // Oprește toate corutinele și afișează instantaneu textul complet al liniei curente
                StopAllCoroutines();
                textComponent.text = lines[index];
            }
        }
    }

    // Inițiază dialogul setând indexul la 0 și începe corutina pentru afișarea textului
    void StartDialogue()
    {
        index = 0;
        StartCoroutine(TypeLine());
    }

    // Corutină care afișează linia de text caracter cu caracter
    IEnumerator TypeLine()
    {
        foreach (char c in lines[index].ToCharArray())
        {
            textComponent.text += c;
            yield return new WaitForSeconds(textSpeed);
        }
    }

    // Trecerea la următoarea linie de dialog
    void NextLine()
    {
        if (index < lines.Length - 1)
        {
            index++;
            textComponent.text = string.Empty;
            StartCoroutine(TypeLine());
        }
        else
        {
            // Dezactivează obiectul de dialog când toate liniile au fost afișate
            gameObject.SetActive(false);
        }
    }
}
