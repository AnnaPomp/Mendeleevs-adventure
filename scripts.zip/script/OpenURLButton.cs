using UnityEngine;

public class OpenURLButton : MonoBehaviour
{
    // URL to redirect to
    public string websiteURL = "https://mail.google.com/mail/u/0/#inbox?compose=new";

    // Function to call when the button is clicked
    public void OpenWebsite()
    {
        // Open the URL
        Application.OpenURL(websiteURL);
    }
}
