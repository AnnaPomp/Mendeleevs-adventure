using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using BeardedManStudios.Forge.Networking.Generated;
using BeardedManStudios.Forge.Networking;
using UnityEngine.UI;

public class ChatterManager : ChatterManagerBehavior
{
    // Transform pentru a conține mesajele de chat
    public Transform chatContent;

    // Prefab-ul pentru mesajul de chat
    public GameObject chatMessage;

    // Metodă pentru a trimite un mesaj
    public void WriteMessage(InputField sender)
    {
        // Verifică dacă textul nu este gol și are o lungime mai mare decât 0 după eliminarea spațiilor
        if (!string.IsNullOrEmpty(sender.text) && sender.text.Trim().Length > 0)
        {
            // Elimină caracterele de newline și carriage return din text
            sender.text = sender.text.Replace("\r", string.Empty).Replace("\n", string.Empty);

            // Trimite mesajul tuturor receptorilor prin RPC
            networkObject.SendRpc(RPC_TRANSMIT_MESSAGE, Receivers.All, "Brent", sender.text.Trim());

            // Golește câmpul de input și îl reactivează pentru următorul mesaj
            sender.text = string.Empty;
            sender.ActivateInputField();
        }
    }

    // Suprascrie metoda TransmitMessage pentru a procesa mesajele recepționate
    public override void TransmitMessage(RpcArgs args)
    {
        // Extrage username-ul și mesajul din argumentele RPC
        string username = args.GetNext<string>();
        string message = args.GetNext<string>();

        // Verifică dacă username-ul sau mesajul sunt goale
        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(message))
        {
            // Mesajul sau username-ul era gol, deci ieșim din metodă
            return;
        }

        // Instanțiază un nou obiect de mesaj în conținutul de chat
        GameObject newMessage = Instantiate(chatMessage, chatContent);

        // Obține componenta Text a noului mesaj și setează textul cu username-ul și mesajul
        Text content = newMessage.GetComponent<Text>();
        content.text = string.Format(content.text, username, message);
    }
}
