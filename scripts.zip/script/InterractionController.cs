using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class InteractionController : MonoBehaviour
{
    //public Text interactText;  // Assign the UI Text component in the Inspector
    private bool isNearObject = false;
    private GameObject currentInteractable;

   

    void Update()
    {
        if (isNearObject && Input.GetKeyDown(KeyCode.E))
        {
            InteractWithObject();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Interactable"))
        {
            currentInteractable = other.gameObject;
          
            isNearObject = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Interactable"))
        {
           
            isNearObject = false;
            currentInteractable = null;
        }
    }

    void InteractWithObject()
    {
        Debug.Log("Interacted with " + currentInteractable.name);
        // Change to the desired scene when interacting with the object
        SceneManager.LoadScene("flashcardalcani"); // Replace "YourSceneName" with the name of your target scene
    }
}
