using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader1 : MonoBehaviour
{
    // Name of the scene to load public string sceneToLoad;

    // Delay before loading the scene (in seconds)
   public float delayInSeconds = 60f; // 2 minutes

    void Start()
    {
        // Start the delay
        Invoke("LoadSceneWithDelay", delayInSeconds);
    }

    void LoadSceneWithDelay()
    {
        // Check if the scene name is not empty
        if (!string.IsNullOrEmpty("Level 3"))
        {
            // Load the specified scene
            SceneManager.LoadScene("Level 3");
        }
        else
        {
            Debug.LogError("Scene name to load is not provided.");
        }
    }
}
