using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miscari : MonoBehaviour
{
 private Rigidbody2D rb;
 private BoxCollider2D coll; 
 private Animator anim;
 private float dirX=0f;

private bool canDash=true;
private bool isDashing;
private float dashingPower=24f;
private float dashingTime=0.2f;
private float dashingCooldown=1f;
 
 private SpriteRenderer sprite;
 [SerializeField]private float movespeed=7f;
 [SerializeField]private float jumpforce=14f;
 [SerializeField] private LayerMask jumpableGround;
 [SerializeField] private TrailRenderer tr;
private enum MovementState {idle, running, jumping, falling }


    // Start is called before the first frame update
   private  void Start()
    {
      rb = GetComponent<Rigidbody2D>();
      anim=GetComponent<Animator>();
      sprite=GetComponent<SpriteRenderer>();
      coll=GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
   private void Update()
    {
      if(isDashing)
      {
        return;
      }
         dirX = Input.GetAxisRaw ("Horizontal");
         rb.velocity= new Vector2(dirX*movespeed, rb.velocity.y);
       
        if(Input.GetButtonDown("Jump")&& IsGrounded())
        { 
          rb.velocity = new Vector2(rb.velocity.x,jumpforce);
        } 
        if(Input.GetKeyDown(KeyCode.RightShift)&&canDash)
        {
          StartCoroutine(Dash());
        }
            UpdateAnimationState();
    }
     


        private void UpdateAnimationState()
        {
          MovementState state;

        if(dirX> .1f)
        {
          state = MovementState.running;
            sprite.flipX=false;
        }
        else if(dirX< -.1f)
        {
          state = MovementState.running;
          sprite.flipX=true;
        }
        else 
        {
        state = MovementState.idle;
        }

        if(rb.velocity.y> .1f)
        {
         state= MovementState.jumping;
        }
        else if(rb.velocity.y< -.1f)
        {
          state= MovementState.falling;
        }

        anim.SetInteger("state", (int)state);
        }



        private bool IsGrounded ()
        {
         return Physics2D.BoxCast(coll.bounds.center, coll.bounds.size, 0f, Vector2.down, .1f,jumpableGround );
        }
        public IEnumerator Dash()
{
  canDash=false;
  isDashing=true;
  float originalGravity =rb.gravityScale;
  rb.gravityScale=0f;
  rb.velocity=new Vector2(transform.localScale.x*dashingPower,0f);
  tr.emitting=true;
  yield return new WaitForSeconds(dashingTime);
  tr.emitting=false;
  rb.gravityScale=originalGravity;
  isDashing=false;
  yield return new WaitForSeconds(dashingCooldown);
  canDash=true;

}
}
