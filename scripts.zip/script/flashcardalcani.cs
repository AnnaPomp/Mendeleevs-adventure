using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Clasa Alcani conține întrebarea și răspunsul corect
public class Alcani
{
    public string question;
    public string correctAnswer;

    public Alcani(string q, string c)
    {
        question = q;
        correctAnswer = c;
    }
}

public class flashcardalcani : MonoBehaviour
{
    // Referință la RectTransform pentru a scala cardul
    public RectTransform r;

    // Referință la componenta Text pentru afișarea întrebării și răspunsului
    public Text cardText;

    // Array de întrebări și răspunsuri
    public Alcani[] ques = new Alcani[100];

    // Timpul necesar pentru flip-ul cardului
    private float flipTime = 0.5f;

    // 0 pentru fața cu întrebarea, 1 pentru fața cu răspunsul
    private int faceSide = 0;

    // Indicator pentru micșorarea cardului în timpul flip-ului
    private int isShrinking = -1;

    // Flag pentru a indica dacă cardul este în proces de flip
    private bool isFlipping = false;

    // Indexul curent al cardului
    private int cardNum = 0;

    // Distanța de scalare pe unitate de timp
    private float distancePerTime;

    // Timpul trecut de la începutul flip-ului
    private float timeCount = 0;

    void Start()
    {
        // Inițializează întrebările și răspunsurile
        ques[0] = new Alcani("Alcanii sunt hidrocarburi _____, fiind alcătuiți din ______ și de hidrogen aranjați într-o catenă ____sau ______.", "aciclice saturate,atomi de carbon, liniară, ramificată");
        ques[1] = new Alcani("Substanțe care au aceeași formulă moleculară, dar diferă prin structura lor, si in consecinta si prin proprietatile lor", "izomeri");
        ques[2] = new Alcani("Câți izomeri de catenă are C₇H₁₆?", "9 izomeri de catenă");
        ques[3] = new Alcani("Ce legaturi se găsesc în moleculele alcanilor", "numai legături simple de tipul C-H si C-C");
        ques[4] = new Alcani("Cum se numește alcanul cu 20 de atomi de C în moleculă", "C₂₀H₄₂ eicosan");
        ques[5] = new Alcani("Ce sunt izomerii de catenă?", "Substanțele care se deosebesc doar prin modul de aranjare a atomilor de carbon în molecule");
        ques[6] = new Alcani("Atomul de carbon are pe ultimul strat", "4 electroni(de valență)");
        ques[7] = new Alcani("Cei 4 electroni de pe ultimul strat al carbonului sunt____", "2 dintre ei sunt situați în orbitali de tip s și au spin opus și 2 sunt situați în orbitali de tip p si au spin paralel");
        ques[8] = new Alcani("La ce temperatură reacționează acetilena cu sodiul metalic?", "150 de grade");
        ques[9] = new Alcani("Cum se numește radicalul -CH3", "radical metil");
        ques[10] = new Alcani("Ce orbitali au alchinele?", "sp");

        // Calculează distanța de scalare pe unitate de timp
        distancePerTime = r.localScale.x / flipTime;

        // Setează prima întrebare
        cardNum = 0;
        cardText.text = ques[cardNum].question;
    }

    void Update()
    {
        // Verifică dacă cardul este în proces de flip
        if (isFlipping)
        {
            Vector3 v = r.localScale;
            v.x += isShrinking * distancePerTime * Time.deltaTime;
            r.localScale = v;

            timeCount += Time.deltaTime;

            // Dacă timpul pentru micșorare a expirat
            if (timeCount >= flipTime && isShrinking < 0)
            {
                isShrinking = 1;
                timeCount = 0;

                // Schimbă fața cardului
                if (faceSide == 0)
                {
                    faceSide = 1;
                    cardText.text = ques[cardNum].correctAnswer;
                }
                else
                {
                    faceSide = 0;
                    cardText.text = ques[cardNum].question;
                }
            }
            // Dacă timpul pentru mărire a expirat
            else if (timeCount >= flipTime && isShrinking == 1)
            {
                isFlipping = false;
            }
        }
    }

    // Metodă pentru a trece la următorul card
    public void NextCard()
    {
        faceSide = 0;
        cardNum++;
        if (cardNum >= ques.Length)
        {
            cardNum = 0;
        }
        cardText.text = ques[cardNum].question;
    }

    // Metodă pentru a începe flip-ul cardului
    public void FlipCard()
    {
        timeCount = 0;
        isFlipping = true;
        isShrinking = -1;
    }
}
