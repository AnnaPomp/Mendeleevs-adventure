using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fallingplatform : MonoBehaviour
{
    // Timpul de întârziere înainte ca platforma să înceapă să cadă
    [SerializeField] private float fallDelay = 1f;

    // Timpul de întârziere înainte ca platforma să fie distrusă după ce a început să cadă
    private float destroyDelay = 2f;

    // Referință la componenta Rigidbody2D a platformei
    [SerializeField] private Rigidbody2D rb;

    // Metodă apelată la coliziunea cu alt obiect 2D
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Verifică dacă obiectul care a lovit platforma are tag-ul "PERSONAJ"
        if (collision.gameObject.CompareTag("PERSONAJ"))
        {
            // Inițiază corutina pentru a începe căderea platformei
            StartCoroutine(Fall());
        }
    }   

    // Corutină care gestionează căderea platformei
    private IEnumerator Fall()
    {
        // Așteaptă pentru o perioadă de timp specificată de fallDelay
        yield return new WaitForSeconds(fallDelay);

        // Setează tipul corpului rigid la Dinamic pentru a permite căderea platformei
        rb.bodyType = RigidbodyType2D.Dynamic;

        // Distruge platforma după o perioadă de timp specificată de destroyDelay
        Destroy(gameObject, destroyDelay);
    }
}
