using System.ComponentModel;
using System.Net.Mail;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EmailUtility : MonoBehaviour
{
    // Metoda Start este apelată înainte de primul frame update
    void Start()
    {
        // Configurează clientul SMTP pentru a folosi Gmail
        SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
        client.Credentials = new System.Net.NetworkCredential(
            "annapomparau@gmail.com", 
            "anapomparau2006");
        client.EnableSsl = true;

        // Specifică expeditorul email-ului
        MailAddress from = new MailAddress(
            "annapomparau@gmail.com",
            "Ana",
            System.Text.Encoding.UTF8);

        // Specifică destinatarul email-ului
        MailAddress to = new MailAddress("ana.pomparau@lme.ro");

        // Creează mesajul de email
        MailMessage message = new MailMessage(from, to);
        message.Body = "This is a test email message sent by an application.";
        message.BodyEncoding = System.Text.Encoding.UTF8;
        message.Subject = "test message 1";
        message.SubjectEncoding = System.Text.Encoding.UTF8;

        // Setează metoda care este apelată când operațiunea de trimitere se termină
        client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);

        // Obiectul userState poate fi orice obiect care permite metodei callback
        // să identifice această operațiune de trimitere. În acest exemplu, userToken este un string constant.
        string userState = "test message1";

        // Trimite mesajul de email asincron
        client.SendAsync(message, userState);
    }

    // Callback pentru când trimiterea email-ului este completă
    private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
    {
        // Obține identificatorul unic pentru această operațiune asincronă
        string token = (string)e.UserState;

        if (e.Cancelled)
        {
            Debug.Log("Send canceled: " + token);
        }
        if (e.Error != null)
        {
            Debug.Log("[ " + token + " ] Error: " + e.Error.ToString());
        }
        else
        {
            Debug.Log("Message sent.");
        }
    }

    // Metodă pentru a încărca scena "Email"
    public void haloo()
    {
        SceneManager.LoadScene("Email");
    }
}
