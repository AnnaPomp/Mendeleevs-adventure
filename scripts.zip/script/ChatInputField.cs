using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChatInputField : MonoBehaviour
{
    // Referință către managerul de chat
    public ChatterManager chatManager;
    
    // Referință către componenta InputField
    private InputField inputField;

    private void Start()
    {
        // Obține componenta InputField atașată obiectului curent
        inputField = GetComponent<InputField>();
    }

    public void ValueChanged()
    {
        // Verifică dacă textul conține un newline (Enter)
        if (inputField.text.Contains("\n"))
        {
            // Trimite mesajul prin managerul de chat
            chatManager.WriteMessage(inputField);
        }
    }
}
