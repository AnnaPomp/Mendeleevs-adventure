using UnityEngine;

public class Shake : MonoBehaviour
{
    // Intensity of the shake
    public float shakeIntensity = 0.1f;

    // Speed of the shake
    public float shakeSpeed = 1.0f;

    // Duration of the shake
    public float shakeDuration = 1.0f;

    // Original position of the ground
    private Vector3 originalPosition;

    // Timer for the shake duration
    private float shakeTimer = 0.0f;

    void Start()
    {
        // Save the original position of the ground
        originalPosition = transform.position;
    }

    void Update()
    {
        // Calculate the shake amount using Perlin noise
        float offsetX = Mathf.PerlinNoise(Time.time * shakeSpeed, 0) * shakeIntensity;
        float offsetY = Mathf.PerlinNoise(0, Time.time * shakeSpeed) * shakeIntensity;

        // Apply the shake to the ground's position
        transform.position = originalPosition + new Vector3(offsetX, offsetY, 0);

        // Clamp the shake intensity to avoid extreme values
        shakeIntensity = Mathf.Clamp(shakeIntensity, 0, 0.5f);
    }
}
