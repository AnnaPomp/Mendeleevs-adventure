using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class loginmamica : MonoBehaviour
{
     public void amdeja()
{
SceneManager.LoadScene("Meniu profesori");
} 
}
