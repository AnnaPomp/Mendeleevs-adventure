using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{
    [SerializeField] private string targetSceneName = "Login";

    public void LoadTargetScene()
    {
        SceneManager.LoadScene(targetSceneName);
    }
}
