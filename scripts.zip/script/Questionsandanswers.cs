
[System.Serializable]
public class Questionsandanswers 
{
  public string Question;
  public string[] Answers;
   public int CorrectAnswer;
}
