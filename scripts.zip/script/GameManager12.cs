using UnityEngine;
using UnityEngine.UI;
using Cinemachine;
public class GameManager12 : MonoBehaviour
{
    public GameObject skinPanel;
    public CinemachineVirtualCamera VCam;
    private float dirX = 0f;
 
    public GameObject[] playerprefabs;
    int characterIndex;

    private void Awake()
    {
        characterIndex = PlayerPrefs.GetInt("Selectat", 0);
       GameObject player= Instantiate(playerprefabs[characterIndex], Vector3.zero, Quaternion.identity);
        VCam.m_Follow=player.transform;

    }

    public void OpenSkinPanel()
    {
        skinPanel.SetActive(true);
    }

    public void CloseSkinPanel()
    {
        skinPanel.SetActive(false);
    }

}
