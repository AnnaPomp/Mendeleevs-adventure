using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthDisplay : MonoBehaviour
{
    public int health; // Sănătatea curentă
    public int maxHealth; // Sănătatea maximă
    public Sprite emptyHeart; // Imaginea pentru inima goală
    public Sprite fullHeart; // Imaginea pentru inima plină
    public Image[] hearts; // Array de imagini pentru afișarea inimilor
    public PlayerLife playerHealth; // Referință la componenta PlayerLife

    // Update este apelat o dată pe cadru
    void Update()
    {
        // Actualizează sănătatea și sănătatea maximă pe baza componentului PlayerLife
        health = playerHealth.health;
        maxHealth = playerHealth.maxHealth;

        // Actualizează display-ul inimilor
        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < health)
            {
                hearts[i].sprite = fullHeart; // Afișează inima plină
            }
            else
            {
                hearts[i].sprite = emptyHeart; // Afișează inima goală
            }

            // Activează sau dezactivează inima pe baza sănătății maxime
            hearts[i].enabled = i < maxHealth;
        }
    }
}
