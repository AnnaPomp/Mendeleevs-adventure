using UnityEngine;

public class HideObject : MonoBehaviour
{
    public GameObject objectToHide;

    // This function will be called when the button is pressed
    public void hiide()
    {
        // Check if the object to hide is not null
        if (objectToHide != null)
        {
            // Set the object to inactive, which effectively hides it
            objectToHide.SetActive(false);
        }
        else
        {
            Debug.LogWarning("Object to hide is not assigned!");
        }
    }
}
