using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Rename the Question class to Nujt
public class Nujt
{
    public string question;
    public string correctAnswer;

    public Nujt(string q, string c)
    {
        question = q;
        correctAnswer = c;
    }
}

public class flashcardd : MonoBehaviour
{
    public RectTransform r;
    public Text cardText;
    public Nujt[] ques = new Nujt[100];
    private float flipTime = 0.5f;
    private int faceSide = 0;
    private int isShrinking = -1;
    private bool isFlipping = false;
    private int cardNum = 0;
    private float distancePerTime;
    private float timeCount = 0;

    void Start()
    {
        ques[0] = new Nujt("Alchinele (acetilene) sunt hidrocarburi nesaturate, ____ care conțin o ____ între _____  ", "aciclice, legătură triplă, doi atomi de carbon");
        ques[1] = new Nujt("Formula moleculară generală a alchinelor _____", "CnH2n-2");
        ques[2] = new Nujt("Cum se denumesc alchinele? ", "Denumirea alchinelor se face înlocuind sufixul -an (din denumirea alcanului cu număr identic de atomi de carbon) cu sufixul -ină. Începând de la al treilea termen al seriei omoloage a alchinelor, în denumire se precizează poziția triplei legături.");
        ques[3] = new Nujt("Pentru n=2 alchina se numește ____", "CH≡CH (Etină/Acetilenă) C2H2");
        ques[4] = new Nujt("Pentru n=5 alchine se numește ___", "H3-C≡C-CH2-CH3 (2-Pentină) C5H8");
        ques[5] = new Nujt("Izomerii de catenă sunt cu catenă____și cu catenă _____", " liniară ,ramificată");
        ques[6] = new Nujt("Cine are caracter slab acid în acetilenă?", "Atomii de hidrogen de la capătul alchinelor cu legatură marginală");
        ques[7] = new Nujt("Cum se mai numesc alchinele?", "acetilene");
        ques[8] = new Nujt("La ce temperatură reacționează acetilena cu sodiul metalic?", "150 de grade");
        ques[9] = new Nujt("Cum se numește radicalul -CH3", "radical metil");
        ques[10] = new Nujt("Ce orbitali au alchinele?", "sp");

        distancePerTime = r.localScale.x / flipTime;
        cardNum = 0;
        cardText.text = ques[cardNum].question;
    }

    void Update()
    {
        if (isFlipping)
        {
            Vector3 v = r.localScale;
            v.x += isShrinking * distancePerTime * Time.deltaTime;
            r.localScale = v;

            timeCount += Time.deltaTime;
            if (timeCount >= flipTime && isShrinking < 0)
            {
                isShrinking = 1;
                timeCount = 0;
                if (faceSide == 0)
                {
                    faceSide = 1;
                    cardText.text = ques[cardNum].correctAnswer;
                }
                else
                {
                    faceSide = 0;
                    cardText.text = ques[cardNum].question;
                }
            }
            else if (timeCount >= flipTime && isShrinking == 1)
            {
                isFlipping = false;
            }
        }
    }

    public void NextCard()
    {
        faceSide = 0;
        cardNum++;
        if (cardNum >= ques.Length)
        {
            cardNum = 0;
        }
        cardText.text = ques[cardNum].question;
    }

    public void FlipCard()
    {
        timeCount = 0;
        isFlipping = true;
        isShrinking = -1;
    }
}
