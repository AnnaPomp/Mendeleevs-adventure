using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelTransition : MonoBehaviour
{
    // Set this in the Unity Editor to specify the next level
    public string nextLevelName;

    // This method is called when the UI button is pressed
    public void OnButtonPress()
    {
        // Check if a valid next level name is specified
        if (!string.IsNullOrEmpty(nextLevelName))
        {
            // Load the next level using SceneManager
            SceneManager.LoadScene(nextLevelName);
        }
        else
        {
            Debug.LogError("Next level name is not specified in the LevelTransition script.");
        }
    }
}
