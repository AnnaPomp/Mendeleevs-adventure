using UnityEngine;

public class HealingObject : MonoBehaviour
{
    public int healingAmount = 1;
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PERSONAJ")) 
        {
           
            PlayerLife healthComponent = other.GetComponent<PlayerLife>();
            if (healthComponent != null)
            {
                healthComponent.Heal(healingAmount);

                Destroy(gameObject);
            }
        }
    }
}
