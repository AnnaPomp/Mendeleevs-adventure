using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class skip : MonoBehaviour
{
    public void CCAlcani()
{
SceneManager.LoadScene("CCAlcani");
}
   public void testAlcadiene1()
{
SceneManager.LoadScene("TestAlcadiene1");
}
   public void CCAlchene()
{
SceneManager.LoadScene("CCAlchene");
}
   public void TestAlcani1()
{
SceneManager.LoadScene("TestAlcani1");
}
   public void CCClorurare()
{
SceneManager.LoadScene("CCClorurare");
}
   public void TestAlchene1()
{
SceneManager.LoadScene("TestAlchene1");
}
   public void deconecteaza()
{
SceneManager.LoadScene("profsauelev");
}
   public void bibl()
{
SceneManager.LoadScene("bibliografie");
}
}
