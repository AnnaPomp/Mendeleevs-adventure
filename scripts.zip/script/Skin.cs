using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Skin : MonoBehaviour
{
  public int skinIndex;

  private Image skinImage;
  public void SkinChange()
  {
skinImage=transform.GetChild(0).GetComponent<Image>();
//FindObjectOfType<GameManager12>().SetSkin(skinImage);
  }
}
