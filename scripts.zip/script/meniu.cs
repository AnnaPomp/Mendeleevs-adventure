using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class meniu : MonoBehaviour
{
    public void Nivelul1()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Level 1");
   }
    public void Nivelul2()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Level 2");

    }
     public void Testul1()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Connecting cables");

    }
    public void Nivelul3()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Level 3");
    }
    public void Nivelul4()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Level 4");

    }
     public void Urmpag()
    {
        Time.timeScale=1f;
SceneManager.LoadScene("Meniu 1");

    }
}
