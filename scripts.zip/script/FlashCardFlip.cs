using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Question
{
    public string question;
    public string correctAnswer;

    public Question(string q, string c)
    {
        question = q;
        correctAnswer = c;
    }
}

public class FlashCardFlip : MonoBehaviour
{
    public RectTransform r;
    public Text cardText;
    public Question[] ques = new Question[100];
    private float flipTime = 0.5f;
    private int faceSide = 0;
    private int isShrinking = -1;
    private bool isFlipping = false;
    private int cardNum = 0;
    private float distancePerTime;
    private float timeCount=0;

    void Start()
    {
        ques[0] = new Question("Alcadienele sau _______ sunt hidrocarburi nesaturate (N.E. =2) ", "dienele");
        ques[1] = new Question("Cum se face denumirea alcadienelor?", "Denumirea alcadienelor se face înlocuind sufixul -n (din denumirea alcanului cu număr identic de atomi de carbon) cu sufixul -dienă");
        ques[2] = new Question("Alcadienele sunt izomeri de funcţiune cu _____ ", "alchinele");
        ques[3] = new Question("CH2=C=CH-CH3 se numește____","1,2-Butadiena");
        ques[4] = new Question("Metodă de obținere a izoprenului","prin dehidrogenarea izopentanului");
        ques[5]= new Question("Ce înseamnă dacă o alcadienă este disjunctă sau izolată ","legăturile duble sunt izolate una de cealaltă");
        ques[6] = new Question("Cum se mai numește 2-metil-1,3-butadiena?","izopren");
        ques[7] = new Question("Cum este butadiena din punct de vedere al stării de agregare?","gazoasă");
        ques[8] = new Question("Care alcadiene sunt cele mai reactive?","cele cu duble legătură");
        ques[9] = new Question("Ce se obține în urma reacției de hidrogenare?","alcan");
        ques[10]= new Question("Ce înseamnă dacă o alcadienă este disjunctă sau izolată ","legăturile duble sunt izolate una de cealaltă");

        
        distancePerTime = r.localScale.x / flipTime;
        cardNum = 0;
        cardText.text = ques[cardNum].question;
    }

    void Update()
    {
        if (isFlipping)
        {
            Vector3 v = r.localScale;
           v.x+=isShrinking*distancePerTime*Time.deltaTime;
           r.localScale=v;
           
           timeCount+=Time.deltaTime;
           if(timeCount>=flipTime && isShrinking<0)
           {
            isShrinking=1;
            timeCount=0;
            if(faceSide==0)
            {
                faceSide=1;
                cardText.text=ques[cardNum].correctAnswer;
            }
            else 
            {
                 faceSide=0;
                cardText.text=ques[cardNum].question;
            }

           }
          else if(timeCount>=flipTime && isShrinking==1)
          {
            isFlipping=false;
          } 
        }
    }
    public void NextCard()
    {
        faceSide=0;
        cardNum++;
        if(cardNum>=ques.Length)
        {
            cardNum=0;
        }
        cardText.text=ques[cardNum].question;
    }
    public void FlipCard()
    {
        timeCount=0;
        isFlipping=true;
        isShrinking=-1;
    }
}
