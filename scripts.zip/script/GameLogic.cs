using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    // Numele scenei care urmează să fie încărcată
    public string sceneToLoad;

    // Întârzierea înainte de încărcarea scenei (în secunde)
    public float delayInSeconds = 120f; // 2 minutes

    void Start()
    {
        // Inițiază întârzierea pentru încărcarea scenei
        Invoke("LoadSceneWithDelay", delayInSeconds);
    }

    void LoadSceneWithDelay()
    {
        // Verifică dacă numele scenei nu este gol
        if (!string.IsNullOrEmpty(sceneToLoad))
        {
            // Încarcă scena specificată
            SceneManager.LoadScene(sceneToLoad);
        }
        else
        {
            Debug.LogError("Numele scenei care urmează să fie încărcată nu este specificat.");
        }
    }
}
