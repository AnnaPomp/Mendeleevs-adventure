using UnityEngine;

public class hover1 : MonoBehaviour
{[SerializeField] int size;
   private void OnMouseEnter()
   {
IncreaseScale(true);
   }
   private void OnMouseExit()
   {
IncreaseScale(false);
   }
   private Vector3 initialScale;
   private void Awake()
   {
initialScale=transform.localScale;
   }
   private void IncreaseScale(bool status)
   {
    Vector3 finalScale=initialScale;
    if(status)
    finalScale=size*initialScale;
    transform.localScale=finalScale;
   }
}
