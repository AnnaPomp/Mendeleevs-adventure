using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hearts : MonoBehaviour
{
    public GameObject[] hearts;
    public int life;
private bool dead;

private void Start()
{
life=hearts.Length;
}

    void Update()
    {
    if(dead==true)
{
    //A MURIT
}
    }

  
    public void TakeDamage(int d)
    {
      life=-d; 
      Destroy(hearts[life].gameObject);
      if(life<1)
      {
        dead=true;
      }
    }
}
