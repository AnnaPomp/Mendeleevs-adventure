using UnityEngine;

public class Hover : MonoBehaviour
{
    private Vector3 initialScale; // Scara inițială a obiectului

    private void Awake()
    {
        // Salvează scara inițială a obiectului
        initialScale = transform.localScale;
    }

    private void OnMouseEnter()
    {
        // Mărește scara obiectului când mouse-ul este deasupra
        IncreaseScale(true);
    }

    private void OnMouseExit()
    {
        // Revine la scara inițială când mouse-ul părăsește obiectul
        IncreaseScale(false);
    }

    private void IncreaseScale(bool status)
    {
        // Calculează scara finală pe baza stării
        Vector3 finalScale = initialScale;
        if (status)
        {
            finalScale = 1.1f * initialScale; // Mărește scara
        }
        // Aplică scara calculată
        transform.localScale = finalScale;
    }
}
