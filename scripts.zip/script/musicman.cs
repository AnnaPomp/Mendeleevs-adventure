using System.Collections;
using System.Collections.Generic;
using UnityEngine;
 
public class musicman : MonoBehaviour
{ [SerializeField]  private AudioSource mmSoundEffect;
  private void Update()
  {
     mmSoundEffect.Play();
  }
   
}

